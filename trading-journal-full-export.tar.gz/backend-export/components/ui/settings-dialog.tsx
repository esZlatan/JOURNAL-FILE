import { useState } from "react"
import { Settings } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"

export type PnLDisplayMode = "dollar" | "percentage" | "ticks" | "points" | "rr"

interface SettingsProps {
  hideValues: boolean
  setHideValues: (value: boolean) => void
  pnlDisplayMode: PnLDisplayMode
  setPnlDisplayMode: (mode: PnLDisplayMode) => void
}

export function SettingsDialog({ 
  hideValues, 
  setHideValues, 
  pnlDisplayMode, 
  setPnlDisplayMode 
}: SettingsProps) {
  const [localSettings, setLocalSettings] = useState({
    hideValues,
    pnlDisplayMode
  })
  
  const handleSave = () => {
    setHideValues(localSettings.hideValues)
    setPnlDisplayMode(localSettings.pnlDisplayMode)
  }

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="ghost" size="icon" className="text-gray-400 hover:text-white">
          <Settings className="h-4 w-4" />
          <span className="sr-only">Settings</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Settings</DialogTitle>
          <DialogDescription>
            Customize your trading journal display preferences.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="flex items-center justify-between">
            <Label htmlFor="privacy-mode">Privacy Mode</Label>
            <Switch 
              id="privacy-mode" 
              checked={localSettings.hideValues}
              onCheckedChange={(checked) => setLocalSettings({...localSettings, hideValues: checked})}
            />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="pnl-display">P/L Display Format</Label>
            <Select 
              value={localSettings.pnlDisplayMode} 
              onValueChange={(value) => setLocalSettings({
                ...localSettings, 
                pnlDisplayMode: value as PnLDisplayMode
              })}
            >
              <SelectTrigger id="pnl-display">
                <SelectValue placeholder="Select display format" />
              </SelectTrigger>
              <SelectContent>
                <SelectGroup>
                  <SelectItem value="dollar">Dollar ($)</SelectItem>
                  <SelectItem value="percentage">Percentage (%)</SelectItem>
                  <SelectItem value="ticks">Ticks</SelectItem>
                  <SelectItem value="points">Points</SelectItem>
                  <SelectItem value="rr">Risk/Reward (R:R)</SelectItem>
                </SelectGroup>
              </SelectContent>
            </Select>
          </div>
        </div>
        <DialogFooter>
          <Button type="submit" onClick={handleSave}>Save changes</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}