import React, { createContext, useContext, useState, useEffect } from 'react'

type DisplayUnit = 'currency' | 'percentage' | 'pips'

interface DisplaySettingsContextType {
  privacyMode: boolean
  togglePrivacyMode: () => void
  displayUnit: DisplayUnit
  setDisplayUnit: (unit: DisplayUnit) => void
  isCollapsed: boolean
  toggleSidebar: () => void
}

const DisplaySettingsContext = createContext<DisplaySettingsContextType | undefined>(undefined)

export function DisplaySettingsProvider({ children }: { children: React.ReactNode }) {
  const [privacyMode, setPrivacyMode] = useState<boolean>(false)
  const [displayUnit, setDisplayUnit] = useState<DisplayUnit>('currency')
  const [isCollapsed, setIsCollapsed] = useState<boolean>(false)

  // Load settings from localStorage on initial render
  useEffect(() => {
    const storedPrivacyMode = localStorage.getItem('privacyMode')
    const storedDisplayUnit = localStorage.getItem('displayUnit') as DisplayUnit
    const storedSidebarState = localStorage.getItem('sidebarCollapsed')

    if (storedPrivacyMode) {
      setPrivacyMode(storedPrivacyMode === 'true')
    }

    if (storedDisplayUnit && ['currency', 'percentage', 'pips'].includes(storedDisplayUnit)) {
      setDisplayUnit(storedDisplayUnit)
    }

    if (storedSidebarState) {
      setIsCollapsed(storedSidebarState === 'true')
    }
  }, [])

  // Save settings to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem('privacyMode', privacyMode.toString())
  }, [privacyMode])

  useEffect(() => {
    localStorage.setItem('displayUnit', displayUnit)
  }, [displayUnit])

  useEffect(() => {
    localStorage.setItem('sidebarCollapsed', isCollapsed.toString())
  }, [isCollapsed])

  const togglePrivacyMode = () => {
    setPrivacyMode(prev => !prev)
  }

  const toggleSidebar = () => {
    setIsCollapsed(prev => !prev)
  }

  return (
    <DisplaySettingsContext.Provider
      value={{
        privacyMode,
        togglePrivacyMode,
        displayUnit,
        setDisplayUnit,
        isCollapsed,
        toggleSidebar,
      }}
    >
      {children}
    </DisplaySettingsContext.Provider>
  )
}

export function useDisplaySettings() {
  const context = useContext(DisplaySettingsContext)
  if (context === undefined) {
    throw new Error('useDisplaySettings must be used within a DisplaySettingsProvider')
  }
  return context
}