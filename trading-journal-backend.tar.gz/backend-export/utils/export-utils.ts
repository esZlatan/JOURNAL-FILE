/**
 * Utility functions for exporting data from the trading journal
 */

// Helper function to format date in YYYY-MM-DD format
const formatDate = (date: Date): string => {
  return date.toISOString().split('T')[0];
};

// Convert JSON data to CSV format
export function convertToCSV(data: any[]): string {
  if (data.length === 0) {
    return '';
  }
  
  const headers = Object.keys(data[0]);
  const csvRows = [];
  
  // Add header row
  csvRows.push(headers.join(','));
  
  // Add data rows
  for (const row of data) {
    const values = headers.map(header => {
      const value = row[header];
      // Handle different data types appropriately for CSV
      if (value === null || value === undefined) {
        return '';
      } else if (typeof value === 'string') {
        // Escape quotes and wrap in quotes
        return `"${value.replace(/"/g, '""')}"`;
      } else if (value instanceof Date) {
        return formatDate(value);
      } else {
        return String(value);
      }
    });
    csvRows.push(values.join(','));
  }
  
  return csvRows.join('\n');
}

// Export data as a downloadable CSV file
export function exportAsCSV(data: any[], filename: string): void {
  const csv = convertToCSV(data);
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `${filename}_${formatDate(new Date())}.csv`);
  link.style.visibility = 'hidden';
  
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

// Export data as JSON file
export function exportAsJSON(data: any, filename: string): void {
  const json = JSON.stringify(data, null, 2);
  const blob = new Blob([json], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `${filename}_${formatDate(new Date())}.json`);
  link.style.visibility = 'hidden';
  
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

// Generate a PDF report (using html2pdf library)
export function exportAsPDF(elementId: string, filename: string): void {
  // This is a placeholder for PDF export functionality
  // In a real implementation, you would use a library like html2pdf or jsPDF
  console.log(`Exporting element ${elementId} as PDF with filename ${filename}`);
  alert('PDF export is not implemented in this demo. In a real application, this would export a PDF report.');
  
  // Example implementation with html2pdf (would require the library to be installed)
  /*
  import html2pdf from 'html2pdf.js';
  
  const element = document.getElementById(elementId);
  if (!element) {
    console.error(`Element with ID ${elementId} not found`);
    return;
  }
  
  const opt = {
    margin: 1,
    filename: `${filename}_${formatDate(new Date())}.pdf`,
    image: { type: 'jpeg', quality: 0.98 },
    html2canvas: { scale: 2 },
    jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
  };
  
  html2pdf().set(opt).from(element).save();
  */
}

// Export wrapper function to handle different export formats
export function exportData(data: any, type: 'csv' | 'json' | 'pdf', filename: string, elementId?: string): void {
  switch (type) {
    case 'csv':
      if (Array.isArray(data)) {
        exportAsCSV(data, filename);
      } else {
        console.error('Data must be an array for CSV export');
      }
      break;
    case 'json':
      exportAsJSON(data, filename);
      break;
    case 'pdf':
      if (elementId) {
        exportAsPDF(elementId, filename);
      } else {
        console.error('Element ID is required for PDF export');
      }
      break;
    default:
      console.error(`Unsupported export type: ${type}`);
  }
}